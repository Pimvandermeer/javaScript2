import "./styles.css";

function checkString() {
  console.log("test");
}
