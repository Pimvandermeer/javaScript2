import "./styles.css";

const url = "https://jsonplaceholder.typicode.com/users";

// Step 1: create an XHR object
const xhr = {};

xhr.onreadystatechange = () => {
  // Step 2: check for the right status
  if (xhr.status === "") {
    console.log(xhr.response);
  } else {
    console.error("Error!");
  }
};

// Step 3 create a `GET` request and use the url from line 3
xhr.open();

xhr.send();

// Step 4: display the response on the page. Don't forget to deserialize
// the JSON into a JavaScript object
